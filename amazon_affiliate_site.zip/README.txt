Amazon Affiliate Website Template
=================================

How to use:
1. Replace 'YOUR_AMAZON_ASSOCIATE_LINK_X' in index.html with your real Amazon affiliate links.
2. Swap images/placeholder.jpg with product images from Amazon's SiteStripe tool.
3. Keep the affiliate disclosure in the footer (required by Amazon).

Deploy for free:
- GitHub Pages: Upload the repo and enable Pages in settings.
- Netlify: Drag & drop this folder into Netlify dashboard.
- Vercel: Import the repo into Vercel and deploy.

That's it! Your site will be live at no cost.
